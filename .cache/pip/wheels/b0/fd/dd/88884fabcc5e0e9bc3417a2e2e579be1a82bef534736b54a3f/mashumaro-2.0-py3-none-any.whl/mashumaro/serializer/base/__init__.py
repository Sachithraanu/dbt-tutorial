from .dict import DataClassDictMixin

__all__ = ["DataClassDictMixin"]
